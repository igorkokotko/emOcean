import axios from 'axios'

const getDefaultState = () => {
  return {
    list: []
  }
}

export default {
  actions: {
    clear ({ commit }) {
      commit('clear')
    },
    getLikedList (ctx, videoId) {
      axios.get(`/api/posts/get-post-likes/?id=${videoId}`)
        .then((response) => {
          ctx.commit('updateLikedList', response.data.result)
        })
        .catch(error => {
          console.log(error.statusText)
        })
    }
  },

  mutations: {
    clear (state) {
      Object.assign(state, getDefaultState())
    },
    updateLikedList (state, list) {
      state.list = list
    }
  },

  state: getDefaultState(),

  getters: {
    getLikes (state) {
      return state.list
    }
  }
}
