export const customCollor = [
  {
    type: 'primary',
    value: '#00BCD4'
  },
  {
    type: 'secondary',
    value: '#B2EBF2'
  },
  {
    type: 'accent',
    value: '#80DEEA'
  },
  {
    type: 'negative',
    value: '#FF1744'
  }
]
