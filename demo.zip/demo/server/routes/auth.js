const express = require('express')
const router = express.Router()
const protectedMiddleware = require('../middleware/protectRoute')
const {
  register,
  login,
  checkToken,
  sendPasswordResetCode,
  resetPassword,
  signInWithGoogle,
  changePassword,
  deleteAccount
} = require('../controllers/auth')

router.post('/register', register)
router.post('/login', login)
router.post('/login-with-google', signInWithGoogle)

router.post('/change-password', protectedMiddleware, changePassword)

router.post('/send-password-reset-code', sendPasswordResetCode)
router.post('/reset-password', resetPassword)

router.get('/check-token', protectedMiddleware, checkToken)

router.delete('/delete-account', protectedMiddleware, deleteAccount)

module.exports = router
