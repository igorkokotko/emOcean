const firebasePackage = require('firebase')
require('firebase/auth')
require('firebase/storage')
require('firebase/firestore')

firebasePackage.initializeApp({
  apiKey: "AIzaSyD6uvfVLjKYpeExjLZx5yqSW1q8xpk6uAY",
  authDomain: "emocean-258512.firebaseapp.com",
  databaseURL: "https://emocean-258512.firebaseio.com",
  projectId: "emocean-258512",
  storageBucket: "emocean-258512.appspot.com",
  messagingSenderId: "949748787521",
  appId: "1:949748787521:web:7b2025ba68e3d0d083d9c0"
})

const db = firebasePackage.firestore()
const storage = firebasePackage.storage()
const auth = firebasePackage.auth

module.exports = {
  firebase: firebasePackage,
  db,
  auth,
  storage
}
